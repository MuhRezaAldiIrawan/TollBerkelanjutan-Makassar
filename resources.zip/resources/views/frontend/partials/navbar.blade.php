<nav class="navbar navbar-expand-lg navbar-light header-navbar navbar-fixed">
  <div class="container-fluid navbar-wrapper">
      <div class="navbar-header d-flex">
          <div class="navbar-toggle menu-toggle d-xl-none d-block float-left align-items-center justify-content-center" data-toggle="collapse">
            <i class="ft-menu font-medium-3"></i>
          </div>
          
          <div class="navbar-brand-center">
            <div class="navbar-header">
              <ul class="navbar-nav">
                <li class="nav-item">
                  <div class="logo">
                      <div class="logo-img">
                        <img class="logo-img" src="{{ asset('apexnew/app-assets/img/Logo_MMN_JTSE.png') }}">
                      </div>
                    </a>
                  </div>
                </li>
              </ul>
            </div>
          </div>
      </div>
      <div class="navbar-container" style="visibility: hidden;">
        <div class="collapse navbar-collapse d-block" id="navbarSupportedContent">
            <ul class="navbar-nav">
                <li class="dropdown nav-item mr-1">
             <a class="nav-link dropdown-toggle user-dropdown d-flex align-items-end" id="dropdownBasic2" href="javascript:;" data-toggle="dropdown">
                        <img height="55" width="55">
                    </a>
                </li>
            </ul>
        </div>
      </div>    
  </div>
</nav>
<!-- Navbar (Header) Ends-->
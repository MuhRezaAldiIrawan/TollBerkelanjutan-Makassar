<?php

return [
    'site_title' => 'Project',
];

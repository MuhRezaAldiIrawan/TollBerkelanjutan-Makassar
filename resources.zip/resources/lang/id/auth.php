<?php

return [
    'failed'   => 'Email atau Password anda salah, silakan coba lagi!',
    'throttle' => 'Terlalu banyak percobaan login, silakan coba kembali dalam   :seconds detik',
];